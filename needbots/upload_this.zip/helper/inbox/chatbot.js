const { query } = require("../../database/dbpromise");

async function processWebhook(params) {}

module.exports = { processWebhook };
