const fetch = require("node-fetch");
const fs = require("fs");

function singleReplyAi() {
  console.log("PLEASE ADD ADDON FOR AI USE");
}

module.exports = { singleReplyAi };
